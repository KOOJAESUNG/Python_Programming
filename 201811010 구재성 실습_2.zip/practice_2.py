age = 19
height = 150

if (age < 19 and height > 140):
   print("탑승 가능합니다.\n");
else:
    print("탑승 불가능합니다.\n")