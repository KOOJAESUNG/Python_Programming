score=int(input("총 학점을 입력하시오:"))

if (score>=140):
    print("졸업 가능합니다.\n")
else:
    print("졸업 불가능합니다.\n")

