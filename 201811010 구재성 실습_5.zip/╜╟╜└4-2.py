num1=float(input("실수1 입력: "))
num2=float(input("실수2 입력: "))

print("{:.2f} + {:.2f} = {:8.2f}".format(num1,num2,num1+num2))
print("{:.2f} - {:.2f} = {:8.2f}".format(num1,num2,num1-num2))
print("{:.2f} * {:.2f} = {:8.2f}".format(num1,num2,num1*num2))
print("{:.2f} / {:.2f} = {:8.2f}".format(num1,num2,num1/num2))
