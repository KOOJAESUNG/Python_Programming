num1=int(input("정수1 입력: "))
num2=int(input("정수2 입력: "))

print("%d + %d = %5d"%(num1,num2,num1+num2))
print("%d - %d = %5d"%(num1,num2,num1-num2))
print("%d * %d = %5d"%(num1,num2,num1*num2))
print("%d / %d = %5.2f"%(num1,num2,num1/num2))
