temp = float(input("섭씨 온도를 입력하시오: "))
print("섭씨온도: %.2f"%temp)
print("화씨온도: %.2f"%(temp*(9/5)+32))
