num1=int(input("정수1 입력: "))
num2=int(input("정수2 입력: "))

print("{} + {} = {:5d}".format(num1,num2,num1+num2))
print("{} - {} = {:5d}".format(num1,num2,num1-num2))
print("{} * {} = {:5d}".format(num1,num2,num1*num2))
print("{} / {} = {:5.2f}".format(num1,num2,num1/num2))
