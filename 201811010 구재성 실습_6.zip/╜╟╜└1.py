def sum(a, b):
    return a + b


print("|테스트|")
a = int(input("숫자 1: "))
b = int(input("숫자 2: "))
print("%d + %d = %d" % (a, b, sum(a, b)))
