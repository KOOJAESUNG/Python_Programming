x1=3
y1=5
x2=-1
y2=4
print("x1:",x1,"y1:",y1,"\nx2:",x2,"y2:",y2)
delta_y=y2-y1
delta_x=x2-x1
triangle_area=(delta_x*delta_y)/2
print(triangle_area)


