inch_len = float(input("인치 수를 입력하시오"))
cm_len=inch_len*2.54
print(inch_len,"인치는",cm_len,"cm입니다.")

