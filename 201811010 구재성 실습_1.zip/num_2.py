x = int(input("x를 입력하시오"))
print("@"*x)
