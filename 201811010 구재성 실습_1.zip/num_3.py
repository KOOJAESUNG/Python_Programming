last = input("last_name을 입력하시오")
first = input("first_name을 입력하시오")
print(first+last)
