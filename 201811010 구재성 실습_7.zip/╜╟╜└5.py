list = []
for i in range(10, 101, 10):
    list.append(i)
_tuple = tuple(list)
for i in _tuple:
    print(i)
